import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HeadlinesComponent } from './headlines/headlines.component';
import { HttpClientModule } from '@angular/common/http';
import { ApiServiceService } from './service/ApiService/api-service.service';

@NgModule({
  declarations: [
    AppComponent,
    HeadlinesComponent
  ],
  imports: [
    BrowserModule, HttpClientModule,
  ],
  providers: [ApiServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
