// tslint:disable-next-line:no-empty-interface
export interface IHeadlineModule extends HeadlineModule {}

export class HeadlineModule {
SourceId: string;
SourceName: string;
author: string;
content: string;
description: string;
publishedAt: string;
title: string;
url: string;
urlToImage: string;
}


