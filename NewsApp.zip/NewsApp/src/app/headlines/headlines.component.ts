import { IHeadlineModule, HeadlineModule } from './../service/Module/headline-module';
import { Component, OnInit } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';
import { ApiServiceService } from '../service/ApiService/api-service.service';

@Component({
  selector: 'app-headlines',
  templateUrl: './headlines.component.html',
  styleUrls: ['./headlines.component.scss']
})
export class HeadlinesComponent implements OnInit {
public headlineList: Array<IHeadlineModule> = [];
private headLineObjects: object[];
private statusStr: string;
public headlineObject: object[];
private sourceObj: object[];
private headlineListStub = new BehaviorSubject<Array<IHeadlineModule>>(this.headlineList);
  constructor(private ApiService: ApiServiceService) { }

  ngOnInit() {
    this.getheadlines();
  }

  getheadlines(): Observable<Array<IHeadlineModule>> {
    this.ApiService.getHeadlines().subscribe((headline) => {
    this.headLineObjects = headline;
    this.statusStr = this.headLineObjects['status']; // this gives the status result as OK   Iheadlineobj.author = element['author'],
    this.headlineObject = this.headLineObjects['articles'];
    let Iheadlineobj = new HeadlineModule();
    if ( this.statusStr === 'ok') {
       if (this.headlineObject.length > 0) {
          this.headlineObject.forEach(element => {
          Iheadlineobj = new HeadlineModule();
          this.sourceObj = element['source'],
          Iheadlineobj.author = this.sourceObj['name'],
          Iheadlineobj.urlToImage = element['urlToImage'],
          Iheadlineobj.title = element['title'],
          Iheadlineobj.url = element['url'],
          this.headlineList.push(Iheadlineobj);
        //  console.log(this.headlineList.length);
          console.log(this.headlineObject);
       });

      }
    }
  });
  return this.headlineListStub;
  }
}
